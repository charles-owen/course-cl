/**
 * \file Farm.cpp
 *
 * \author 
 */

#include "stdafx.h"
#include "Farm.h"



/**
 * Constructor.
 */
CFarm::CFarm()
{
}


/**
 * Destructor.
 */
CFarm::~CFarm()
{
	// Iterate over all of the animals, destroying 
	// each one.
	for (auto animal : mInventory)
	{
		delete animal;
	}

	// And clear the list
	mInventory.clear();
}


/** Add an animal to the farm inventory.
*
* \param cow A cow to add to the inventory
*/
void CFarm::AddAnimal(CAnimal *cow)
{
	mInventory.push_back(cow);
}

/**
* Display the farm inventory.
*/
void CFarm::DisplayInventory()
{
	for (auto animal : mInventory)
	{
		animal->DisplayAnimal();
	}
}

/**
 * Count the number of legs.
 * \return Number of legs on the farm.
 */
int CFarm::CountLegs()
{
	int total = 0;
	for (auto animal : mInventory)
	{
		total += animal->NumLegs();
	}

	return total;
}
