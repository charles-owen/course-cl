/**
 * \file Animal.cpp
 *
 * \author Charles B. Owen
 */

#include "stdafx.h"
#include "Animal.h"

/**
 * Constructor
 */
CAnimal::CAnimal()
{
}

/**
 * Destructor
 */
CAnimal::~CAnimal()
{
}
