#include "stdafx.h"
#include <iostream>
#include "Bulbasaur.h"

using namespace std;

CBulbasaur::CBulbasaur()
{
}


CBulbasaur::~CBulbasaur()
{
}

/**
 * Obtain information about this Bulbasaur. 
 * 
 */
void CBulbasaur::ObtainBulbasaurInformation()
{
	cout << endl;
	cout << "Input information about a Bulbasaur" << endl;

	// Obtain the name. This is easy, since it's just a
	// string.
	cout << "Name: ";
	cin >> mName;

	// Obtain the number of candy eaten
	bool valid = false;
	while (!valid)
	{
		cout << "Enter number of candy eaten (0 or more): ";
		int a;
		cin >> a;
		if (cin && a >= 0)
		{
			mCandy = a;
			valid = true;
		}
		else
		{
			cin.clear();
		}
	}

	// Obtain the weight
	valid = false;
	while (!valid)
	{
		cout << "Enter weight in kilograms (greater than zero): ";
		double a;
		cin >> a;
		if (cin && a >= 0)
		{
			mWeight = a;
			valid = true;
		}
		else
		{
			cin.clear();
		}
	}


	// Obtain the skill using a menu. We have a loop so
	// we can handle errors.
	valid = false;
	while (!valid)
	{
		cout << "1: Tackle" << endl;
		cout << "2: Seed Bomb" << endl;
		cout << "Enter type selection for skill and return: ";
		int option;
		cin >> option;
		if (!cin)
		{
			// We have an error. Clear the input and try again
			cin.clear();
			continue;
		}

		switch (option)
		{
		case 1:
			mSkill = Tackle;
			valid = true;
			break;

		case 2:
			mSkill = SeedBomb;
			valid = true;
			break;
		}
	}
}

/**
 * Display the Bulbasaur.
 *
 * This is a virtual function that
 * will be called for this specific animal type.
 */
void CBulbasaur::DisplayAnimal()
{
	cout << "CBulbasaur " << mName << " Weight: " << mWeight
		<< " Candy Eaten: " << mCandy << " Skill: ";
	switch (mSkill)
	{
	case Tackle:
		cout << "Tackle" << endl;
		break;

	case SeedBomb:
		cout << "Seed Bomb" << endl;
		break;
	}

}

