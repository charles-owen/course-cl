/**
* \file Chicken.h
*
* \author Enter_your_name_here
*
* Declaration of the CChicken class.
*/

#pragma once

#include <string>
#include "Animal.h"



/** 
 * Class that describes a chicken.
 */
class CChicken : public CAnimal
{
public:
	/// Number of those chicken legs
	static const int ChickenNumlegs = 2;

	CChicken();
	virtual ~CChicken();

	void ObtainChickenInformation();
	void DisplayAnimal();

	/**
	* How many legs does this animal have?
	*  \return Number of legs (2 for chickens)
	*/
	virtual int NumLegs() const { return ChickenNumlegs; }

private:
	//! The chicken's ID
	std::string mId;
};