/**
 * \file Animal.h
 *
 * \author 
 *
 * Base class for an animal
 */

#pragma once

/**
 * Base class for an animal
 */
class CAnimal
{
public:
	CAnimal();
	virtual ~CAnimal();

	/** Display an animal. */
	virtual void DisplayAnimal() {}

	/**
	* How many legs does this animal have?
	*  \return Number of legs
	*/
	virtual int NumLegs() const { return 0; }
};

