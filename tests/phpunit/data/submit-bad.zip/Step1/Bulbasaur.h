/**
 * \file Bulbasaur.h
 *
 * \author 
 *
 * Class that implements a Bulbasaur
 */

#pragma once
#include <string>
#include "Animal.h"

/**
 * Class that implements a Bulbasaur
 */
class CBulbasaur : public CAnimal
{
public:
	/// Number of legs for a Bulbasaur
	static const int NumBulbasaurLegs = 4;

	CBulbasaur();
	virtual ~CBulbasaur();

	void ObtainBulbasaurInformation();
	virtual void DisplayAnimal();

	/// Types of animal skills
	enum Skills {Tackle, SeedBomb};

	/**
	* How many legs does this animal have?
	*  \return Number of legs (4 for Bulbasaur)
	*/
	virtual int NumLegs() const { return NumBulbasaurLegs; }

private:
	/// The Bulbasaur's name
	std::string mName;

	/// Weight of the Bulbasaur
	double mWeight = 0;

	/// Candy eaten
	int mCandy = 0;

	/// Skill
	Skills mSkill = Tackle;
};

