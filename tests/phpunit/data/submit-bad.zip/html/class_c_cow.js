var class_c_cow =
[
    [ "Type", "class_c_cow.html#a4ef620d923e53e88931717779362db7e", [
      [ "Bull", "class_c_cow.html#a4ef620d923e53e88931717779362db7eaeed2b1db80740fa01ac41a0e35f001e0", null ],
      [ "BeefCow", "class_c_cow.html#a4ef620d923e53e88931717779362db7ead756108e7858f8e8428982f630b7a9ca", null ],
      [ "MilkCow", "class_c_cow.html#a4ef620d923e53e88931717779362db7eafdebaf394cefab6e2d37721e57f54a9b", null ]
    ] ],
    [ "CCow", "class_c_cow.html#a83904248e2f1dda4cb8c1e24c08526e7", null ],
    [ "~CCow", "class_c_cow.html#ae670aafa10b298435172d8e0d565dd7b", null ],
    [ "DisplayAnimal", "class_c_cow.html#a699ab00200436524dfd8610ec127e9f4", null ],
    [ "NumLegs", "class_c_cow.html#a194ecedda7189e9926a08f7dfe25d09b", null ],
    [ "ObtainCowInformation", "class_c_cow.html#a710ef18b09567beedac90550bac7fb83", null ],
    [ "mMilkProduction", "class_c_cow.html#a028ce7266403b00981d3b5e5fcfec28b", null ],
    [ "mName", "class_c_cow.html#a1c2e9614794bba594fb629ce72a1d044", null ],
    [ "mType", "class_c_cow.html#a60e5329514a169bc23c48e463e679501", null ],
    [ "NumCowLegs", "class_c_cow.html#aa3b618cbe8d650ef785dfd47a5bfc6cb", null ]
];