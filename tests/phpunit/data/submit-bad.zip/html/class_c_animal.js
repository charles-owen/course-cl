var class_c_animal =
[
    [ "CAnimal", "class_c_animal.html#a030b88d9d62cffa54da11a6cda1982f9", null ],
    [ "~CAnimal", "class_c_animal.html#ac8d34c4ce380545daf806b8085d36374", null ],
    [ "DisplayAnimal", "class_c_animal.html#adb315185769bcf8ce0458f1955b19f1d", null ],
    [ "NumLegs", "class_c_animal.html#af87cc02bdb5cf1e2fcfbf5691d1ea206", null ]
];