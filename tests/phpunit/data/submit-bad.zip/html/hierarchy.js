var hierarchy =
[
    [ "CAnimal", "class_c_animal.html", [
      [ "CBulbasaur", "class_c_bulbasaur.html", null ],
      [ "CChicken", "class_c_chicken.html", null ],
      [ "CCow", "class_c_cow.html", null ]
    ] ],
    [ "CFarm", "class_c_farm.html", null ]
];