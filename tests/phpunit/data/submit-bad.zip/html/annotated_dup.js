var annotated_dup =
[
    [ "CAnimal", "class_c_animal.html", "class_c_animal" ],
    [ "CBulbasaur", "class_c_bulbasaur.html", "class_c_bulbasaur" ],
    [ "CChicken", "class_c_chicken.html", "class_c_chicken" ],
    [ "CCow", "class_c_cow.html", "class_c_cow" ],
    [ "CFarm", "class_c_farm.html", "class_c_farm" ]
];