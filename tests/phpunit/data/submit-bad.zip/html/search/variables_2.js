var searchData=
[
  ['numbulbasaurlegs',['NumBulbasaurLegs',['../class_c_bulbasaur.html#a2df7636914b446f264e0e2bd75f7d0c8',1,'CBulbasaur']]],
  ['numcowlegs',['NumCowLegs',['../class_c_cow.html#aa3b618cbe8d650ef785dfd47a5bfc6cb',1,'CCow']]]
];
