var searchData=
[
  ['skills',['Skills',['../class_c_bulbasaur.html#a70e2b1475250b4049d626999653e82ff',1,'CBulbasaur']]]
];
