var searchData=
[
  ['numbulbasaurlegs',['NumBulbasaurLegs',['../class_c_bulbasaur.html#a2df7636914b446f264e0e2bd75f7d0c8',1,'CBulbasaur']]],
  ['numcowlegs',['NumCowLegs',['../class_c_cow.html#aa3b618cbe8d650ef785dfd47a5bfc6cb',1,'CCow']]],
  ['numlegs',['NumLegs',['../class_c_animal.html#af87cc02bdb5cf1e2fcfbf5691d1ea206',1,'CAnimal::NumLegs()'],['../class_c_bulbasaur.html#ae9e7e79a89ec2c54c9f38956ff5fcf1e',1,'CBulbasaur::NumLegs()'],['../class_c_chicken.html#a572b26aece4916b41e67db4f071882c3',1,'CChicken::NumLegs()'],['../class_c_cow.html#a194ecedda7189e9926a08f7dfe25d09b',1,'CCow::NumLegs()']]]
];
