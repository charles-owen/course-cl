var searchData=
[
  ['type',['Type',['../class_c_cow.html#a4ef620d923e53e88931717779362db7e',1,'CCow']]]
];
