/**
* \file Buffalo.h
*
* \author Charles B. Owen
*
* Class that implements the animal Buffalo
*/

#pragma once
#include <string>
#include "Animal.h"


/** Implements the animal Buffalo */
class CBuffalo :
    public CAnimal
{
public:
    CBuffalo();
    virtual ~CBuffalo();

    /// The possible Buffalo genders
    enum Gender {Cow, Bull};

    void ObtainBuffaloInformation();
    void DisplayAnimal();

    /*! How many wings does this animal have?
    *  \returns Number of wings
    */
    virtual int NumWings() const { return mNumWings; }

private:
    /// The Buffalo's name
    std::string mName;

    /// The Gender
    Gender mGender = Cow;

    /// Number of wings
    int mNumWings = 0;
};