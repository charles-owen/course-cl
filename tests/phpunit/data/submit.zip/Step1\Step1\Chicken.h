#pragma once
/**
* \file Chicken.h
*
* \author Enter_your_name_here
*
* Declaration of the CChicken class.
*/

#pragma once

#include <string>
#include "Animal.h"

/** Class that describes a chicken
*/
class CChicken : public CAnimal
{
public:
    CChicken();
    virtual ~CChicken();

    void ObtainChickenInformation();
    void DisplayAnimal();

    /*! How many wings does this animal have?
    *  \returns Number of wings (2 for chickens)
    */
    virtual int NumWings() const { return 2; }

private:
    //! The chicken's ID
    std::string mId;
};