#include "stdafx.h"
#include "Animal.h"


CAnimal::CAnimal()
{
}


CAnimal::~CAnimal()
{
}
