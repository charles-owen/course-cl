#pragma once

/**
* Base class for any possible animal.
*/
class CAnimal
{
public:
    CAnimal();
    virtual ~CAnimal();

    /** Display an animal */
    virtual void DisplayAnimal() {}

    /*! How many wings does this animal have?
    *  \returns Number of wings
    */
    virtual int NumWings() const { return 0; }
};

