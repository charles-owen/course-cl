#pragma once

#include <string>
#include "Animal.h"

class CCow : public CAnimal
{
public:
	CCow();
	virtual ~CCow();

	/// The types of cow we can have on our farm
	enum Type { Bull, BeefCow, MilkCow };

	void ObtainCowInformation();
	void DisplayAnimal();

private:
	/// The cow's name
	std::string mName;

	/// The type of code: Bull, BeefCow, or MilkCow
	Type mType;

	/// The milk production for a cow in gallons per day
	double mMilkProduction;
};

