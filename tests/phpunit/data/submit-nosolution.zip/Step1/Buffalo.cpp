#include "stdafx.h"
#include <iostream>
#include "Buffalo.h"


using namespace std;


CBuffalo::CBuffalo()
{
}


CBuffalo::~CBuffalo()
{
}


/*! Obtain information about this Buffalo */
void CBuffalo::ObtainBuffaloInformation()
{
	cout << endl;
	cout << "Input information about a Buffalo" << endl;

	// Obtain the name. This is easy, since it's just a
	// string.
	cout << "Name: ";
	cin >> mName;

	// Obtain the geneder using a menu. We have a loop so
	// we can handle errors.
	bool valid = false;
	while (!valid)
	{
		cout << "1: Cow" << endl;
		cout << "2: Bull" << endl;
		cout << "Enter type selection and return: ";
		int option;
		cin >> option;
		if (!cin)
		{
			// We have an error. Clear the input and try again
			cin.clear();
			continue;
		}

		switch (option)
		{
		case 1:
			mGender = Cow;
			valid = true;
			break;

		case 2:
			mGender = Bull;
			valid = true;
			break;
		}
	}


	// Obtain the number of wings
	valid = false;
	while (!valid)
	{
		cout << "Enter number of wings (0 or more): ";
		int a;
		cin >> a;
		if (cin && a >= 0)
		{
			mNumWings = a;
			valid = true;
		}
		else
		{
			cin.clear();
		}
	}


}

/**
* Display the Buffalo
*
* This is a virtual function that
* will be called for this specific animal type.
*/
void CBuffalo::DisplayAnimal()
{
	cout << "Buffalo " << mName;
	switch (mGender)
	{
	case Cow:
		cout << " Cow ";
		break;

	case Bull:
		cout << " Bull ";
		break;
	}

	cout << " and has " << mNumWings << " wings" << endl;
}
